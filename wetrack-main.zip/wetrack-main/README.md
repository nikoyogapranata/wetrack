# wetrack

Language
Frontend: (HTML, CSS - Bootstrap, JavaScript)
Backend: (Laravel)
Database: (MySQL)