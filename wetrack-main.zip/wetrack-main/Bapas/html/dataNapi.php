<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WETRACK | Database</title>
    <link rel="stylesheet" href="/Bapas/css/dataNapi.css">
    <script src="/Bapas/js/dataNapi.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Parkinsans:wght@300..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Quicksand:wght@300..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
</head>

<body>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="/Bapas/Image/wetrack-logo-white.png" alt="WETRACK Logo">
                    <h1 class="logo-text">WETRACK</h1>
                </div>
                <button id="toggle-sidebar" class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <nav class="nav-links">
                <ul>
                    <li><a href="/Bapas/html/home.html"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
                    <li><a href="/Bapas/html/tracking.html"><i class="fas fa-map-marker-alt"></i> <span>Tracking Map</span></a></li>
                    <li class="active"><a href="/Bapas/html/data.html"><i class="fas fa-database"></i> <span>Database</span></a>
                    </li>
                    <li><a href="/Bapas/html/setting.html"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
                </ul>
            </nav>
            <div class="user-profile">
                <img src="/Bapas/Image/lapas-logo.png" alt="Profile picture" width="40" height="40">
                <div class="user-info">
                    <h2>Serdy Fambo</h2>
                    <p>Admin Officer</p>
                </div>
            </div>
        </aside>
        <main class="content">
            <header class="content-header">
                <div class="search-bar">
                    <input type="text" placeholder="Search" aria-label="Search">
                    <i class="fas fa-search"></i>
                </div>
            </header>
            <div class="profile-card">
                <div class="path-to-back">
                    <a href="/Bapas/html/data.html"><i class="fas fa-arrow-left"></i></a>
                </div>
                <div class="profile-header">
                    <img src="/Image/nanti-diganti.png" alt="John Doe" class="profile-image">
                    <div class="profile-title">
                        <h1>Gita Sekar</h1>
                        <p class="id-text">ID: 06</p>
                    </div>
                </div>

                <div class="profile-content">
                    <div class="info-section">
                        <h2>Informasi Pribadi</h2>
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Jenis Kejahatan:</label>
                                <span>Pencurian</span>
                            </div>
                            <div class="info-item">
                                <label>Masa Hukuman:</label>
                                <span>5 tahun</span>
                            </div>
                            <div class="info-item">
                                <label>Tanggal Bebas:</label>
                                <span>2023-01-15</span>
                            </div>
                            <div class="info-item">
                                <label>Status:</label>
                                <span>Dalam Pengawasan</span>
                            </div>
                            <div class="info-item">
                                <label>Status Alat Pelacak:</label>
                                <span>Aktif</span>
                            </div>
                        </div>
                    </div>

                    <div class="violation-section">
                        <h2>Riwayat Pelanggaran</h2>
                        <div class="violation-list">
                            <div class="violation-item">
                                <span class="violation-date">2023-03-10:</span>
                                <span class="violation-desc">Melewati batas area</span>
                            </div>
                            <div class="violation-item">
                                <span class="violation-date">2023-04-22:</span>
                                <span class="violation-desc">Terlambat lapor diri</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="live-location">
                    <h2>Live Location</h2>
                    <div id="map" class="location-map"></div>
                </div>

                <div class="profile-actions">
                    <button class="btn btn-primary">Kembali ke Dashboard</button>
                    <button class="btn btn-danger">Laporkan Pelanggaran</button>
                </div>
            </div>
        </main>
    </div>
</body>

</html>