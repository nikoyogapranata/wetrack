<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WETRACK | Dashboard</title>
    <link rel="stylesheet" href="/frontend/pages/Lapas/css/style.css">
    <script src="/frontend/pages/Lapas/js/script.js"></script>
    <link rel="icon" href="/frontend/pages/Lapas/Images/wetrack-logo-white.png" type="Image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Parkinsans:wght@300..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Quicksand:wght@300..700&display=swap"
        rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="/frontend/pages/Lapas/Image/wetrack-logo-white.png" alt="WETRACK Logo">
                    <h1 class="logo-text">WETRACK</h1>
                </div>
                <button id="toggle-sidebar" class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <nav class="nav-links">
                <ul>
                    <li class="active"><a href="/frontend/pages/Lapas/html/home.html"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
                    <li><a href="/frontend/pages/Lapas/html/data.html"><i class="fas fa-database"></i> <span>Database</span></a></li>
                    <li><a href="/frontend/pages/Lapas/html/Laporan.html"><i class="fas fa-file-invoice"></i> <span>Final Report</span></a></li>
                    <li><a href="/frontend/pages/Lapas/html/setting.html"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
                </ul>
            </nav>
            <div class="user-profile">
                <img src="/frontend/pages/Lapas/Image/lapas-logo.png" alt="Profile picture" width="40" height="40">
                <div class="user-info">
                    <h2>Serdy Fambo</h2>
                    <p>Administrative Staff</p>
                </div>
            </div>
        </aside>
        <main class="content">
            <div class="dashboard-grid">
                <section class="card summary-card">
                    <h3><i class="fas fa-users"></i>Total Individuals Registered</h3>
                    <div class="card-content">
                        <span class="number">1,365</span>
                    </div>
                    <p class="trend positive">+5% from last month</p>
                    <div class="chart-container">
                        <canvas id="summaryChart"></canvas>
                    </div>
                </section>
                <section class="card alert-card">
                    <h3><i class="fas fa-file-invoice"></i>Total Final Report</h3>
                    <div class="card-content">
                        <span class="number">7</span>
                    </div>
                    <p class="trend negative">Requires immediate attention</p>
                </section>
                <section class="card activity-card">
                    <h3><i class="fas fa-history"></i>Recent Activities</h3>
                    <ul class="activity-list">
                        <li>
                            <span class="time">09:45</span>
                            <span class="activity">New registration added</span>
                        </li>
                        <li>
                            <span class="time">08:30</span>
                            <span class="activity">Alert triggered in Zone B</span>
                        </li>
                        <li>
                            <span class="time">07:15</span>
                            <span class="activity">System update completed</span>
                        </li>
                        <li>
                            <span class="time">Yesterday</span>
                            <span class="activity">Monthly report generated</span>
                        </li>
                        <li>
                            <span class="time">2 days ago</span>
                            <span class="activity">New user account created</span>
                        </li>
                    </ul>
                </section>
            </div>
        </main>
    </div>

</body>

</html>