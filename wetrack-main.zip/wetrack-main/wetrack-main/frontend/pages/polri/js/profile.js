function navigateTo(page) {
    window.location.href = page;
  }

  function logout() {
    alert("You have logged out.");
    window.location.href = 'login.html'; // Redirect to login page
  }
  