<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout - Dashboard</title>
  <link rel="stylesheet" href="/frontend/pages/polri/css/styles.css"> 
  <script src="/frontend/pages/polri/js/logout.js"></script>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h2>Admin Dashboard</h2>
    <ul>
      <li><a href="/frontend/pages/polri/html/index.html">Dashboard</a></li>
      <li><a href="/frontend/pages/polri/html/alerts.html">Alerts</a></li>
      <li><a href="/frontend/pages/polri/html/penanganan.html">Penanganan</a></li>
      <li><a href="/frontend/pages/polri/html/profiles.html">Profile</a></li>
      <li class="active" onclick="logout()">Logout</li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <h1>Logout Page</h1>
    <p>Anda akan keluar dari sistem. Klik tombol di bawah untuk melanjutkan.</p>
    <button class="logout-btn" onclick="logout()">Logout</button>
  </div>
</body>
</html>
