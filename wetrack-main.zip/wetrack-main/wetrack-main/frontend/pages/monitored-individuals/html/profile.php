<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prisoner Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/frontend/pages/monitored-individuals/css/profile.css">
</head>
<body>
    <div class="container">
        <div class="profile-card">
            <div class="profile-header">
                <img src="https://via.placeholder.com/128" alt="Prisoner Photo" class="profile-photo">
                <h1 class="profile-name">John Doe</h1>
                <p class="profile-nik">NIK: 1234567890123456</p>
            </div>
            <div class="profile-info">
                <p><strong>Gender:</strong> Male</p>
                <p><strong>Date of Birth:</strong> 01/01/1990</p>
                <p><strong>Address:</strong> 123 Jalan Raya, Kota Jakarta, 12345</p>
                <p><strong>Status:</strong> Tahanan Rumah/Kota</p>
                <div class="status-pemantauan">
                    <strong>Status Pemantauan:</strong>
                    <span class="badge active">Active</span>
                </div>
                <p><strong>Curfew:</strong> 9:00 PM - 6:00 AM</p>
            </div>
            <button href="/frontend/pages/monitored-individuals/html/final-report.html" id="viewReportBtn" class="btn">View Laporan Akhir</button>
        </div>
    </div>
    <script src="/frontend/pages/monitored-individuals/js/profile.js"></script>
</body>
</html>

