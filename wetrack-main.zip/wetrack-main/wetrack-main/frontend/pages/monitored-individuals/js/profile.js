document.addEventListener('DOMContentLoaded', function() {
  const viewReportBtn = document.getElementById('viewReportBtn');
  
  viewReportBtn.addEventListener('click', function() {
      window.location.href = 'final-report.html';
  });
});