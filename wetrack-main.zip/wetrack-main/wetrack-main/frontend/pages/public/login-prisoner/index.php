<!DOCTYPE html>
<html data-wf-page="676108a2b3193f26b432b712" data-wf-site="676108a1b3193f26b432b6b5" data-wf-status="1">

<head>
  <meta charset="utf-8" />
  <title>Login Interface Design</title>
  <meta content="Login interface design. Made in Webflow, by Mirela Prifti." name="description" />
  <meta content="Login Interface Design" property="og:title" />
  <meta content="Login interface design. Made in Webflow, by Mirela Prifti." property="og:description" />
  <meta content="Login Interface Design" property="twitter:title" />
  <meta content="Login interface design. Made in Webflow, by Mirela Prifti." property="twitter:description" />
  <meta property="og:type" content="website" />
  <meta content="summary_large_image" name="twitter:card" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <meta content="Webflow" name="generator" />
  <link href="css/webflow-style.css" rel="stylesheet" type="text/css" />
  <script
    type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
  <link href="images/favicon.png" rel="shortcut icon" type="image/x-icon" />
  <link href="images/app-icon.png" rel="apple-touch-icon" />
</head>

<body>
  <div class="page-wrapper">
    <div class="page-container _2">
      <div class="block-2">
        <div class="form-wrapper">
          <h2 class="heading-2">Login to WETRACK<br /></h2>
          <div class="form-box">
            <h3 class="heading-4">Please log in with your credentials to access the system. Unauthorized use is strictly
              prohibited and monitored.</h3>
            <div class="div-block-6-copy"></div>
            <div class="w-form">
              <form id="email-form" name="email-form" data-name="Email Form" method="get"
                data-wf-page-id="676108a2b3193f26b432b712" data-wf-element-id="2d58e6ef-9efd-4876-3b8d-aaa0bbbe8a9e"
                data-turnstile-sitekey="0x4AAAAAAAQTptj2So4dx43e">
                <div class="form-field-wrapper">
                  <div class="text-field-box _2"><label for="id" class="field-label-2">ID</label><input
                      class="text-field-2 w-input" maxlength="256" name="id" data-name="id" placeholder="ID" type="text"
                      id="id" required="" /></div>
                  <div class="text-field-box _2"><label for="password-2" class="field-label-2">Password</label><input
                      class="text-field-2 w-input" maxlength="256" name="password" data-name="password"
                      placeholder="Password" type="password" id="password-2" required="" /></div>
                </div><input type="submit" data-wait="Please wait..." class="button registration w-button"
                  value="Login" />
              </form>
              <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
              </div>
              <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
              </div>
            </div>
          </div>
        </div>
        <div class="legal-box _2-copy">
          <div class="legal-text _3">© 2024 WETRACK. All rights reserved.</div>
        </div>
      </div>
    </div>
    <div class="page-container">
      <div class="block-1">
        <div class="content-wrapper"><a href="/frontend/pages/public/landing-page/index.html" class="nav-footer-logo w-nav-brand"><img width="40" sizes="40px" alt=""
              src="images/logo-white.png" loading="lazy"
              srcset="images/logo-white-p-500.png 500w, images/logo-white-p-800.png 800w, images/logo-white-p-1080.png 1080w, images/logo-white-p-1600.png 1600w, images/logo-white-p-2000.png 2000w, images/logo-white.png 2160w"
              class="logo" />
            <div class="logo-text logo-text-footer">WETRACK</div>
          </a>
          <div class="content-box">
            <h1 class="heading-1">Welcome to the monitoring system. Log in to view your profile, curfew schedule, and
              final report.<br /></h1>
          </div>
          <div class="legal-box _2">
            <div class="legal-text">© 2024 WETRACK. All rights reserved.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="js/jquery.js" type="text/javascript"></script>
  <script src="js/webflow-script.js" type="text/javascript"></script>
</body>

</html>