<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WETRACK | Login</title>
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/your-code.js"></script>
    <script src="/js/script.js" defer></script>
</head>

<body>
    <video autoplay muted loop id="background-video">
        <source src="Video/Satellite Tracking GPS Navigation Stock Video Footage.mp4" type="Video/mp4">
    </video>
    <div class="container">
        <div class="login-form">
            <h2><i class="fas fa-shield-alt"></i>WETRACK</h2>
            <form action="">
                <div class="form-group">
                    <label for="email">Email Address*</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="password">Password*</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password">
                </div>
                <div class="form-links">
                    <ul>
                        <li><a href="forgetPass.html"><i class="fas fa-key"></i> Reset Password</a></li>
                        <hr>
                        <li><a href="regist.html"><i class="fas fa-user-plus"></i> New User Registration</a></li>
                    </ul>
                </div>
                <p class="required-note">* Required fields</p>
                <button type="button" class="btn-login" onclick="goToHome()">
                    <i class="fas fa-sign-in-alt"></i> SECURE LOGIN
                </button>
            </form>
        </div>
    </div>
</body>

</html>